// Bulk processing specific JavaScript functionality

// Copy all results to clipboard
function copyAllToClipboard() {
    const results = getBulkResultsData();
    if (!results) return;
    
    let text = `Bulk Date Extraction Results\n`;
    text += `Generated on: ${new Date().toISOString()}\n\n`;
    text += `Summary:\n`;
    text += `--------\n`;
    text += `Total URLs: ${results.length}\n`;
    text += `Successful: ${results.filter(r => !r.error).length}\n`;
    text += `Errors: ${results.filter(r => r.error).length}\n`;
    text += `Total Dates: ${results.reduce((sum, r) => sum + r.total_dates, 0)}\n\n`;
    
    results.forEach((result, index) => {
        text += `${index + 1}. ${result.url}\n`;
        if (result.error) {
            text += `   ERROR: ${result.error}\n`;
        } else {
            text += `   Dates Found: ${result.total_dates}\n`;
            if (result.visible_dates.length > 0) {
                text += `   Visible Content: ${result.visible_dates.join(', ')}\n`;
            }
            if (result.source_dates.length > 0) {
                text += `   Source Code: ${result.source_dates.join(', ')}\n`;
            }
        }
        text += '\n';
    });
    
    navigator.clipboard.writeText(text).then(() => {
        showAlert('All results copied to clipboard!', 'success');
    }).catch(err => {
        console.error('Failed to copy: ', err);
        showAlert('Failed to copy to clipboard.', 'error');
    });
}

// Download all results as text file
function downloadAllAsText() {
    const results = getBulkResultsData();
    if (!results) return;
    
    let text = `Bulk Date Extraction Results\n`;
    text += `${'='.repeat(50)}\n\n`;
    text += `Generated: ${new Date().toISOString()}\n\n`;
    
    text += `Summary:\n`;
    text += `--------\n`;
    text += `Total URLs Processed: ${results.length}\n`;
    text += `Successful Extractions: ${results.filter(r => !r.error).length}\n`;
    text += `Failed Extractions: ${results.filter(r => r.error).length}\n`;
    text += `Total Dates Found: ${results.reduce((sum, r) => sum + r.total_dates, 0)}\n\n`;
    
    text += `Detailed Results:\n`;
    text += `${'='.repeat(20)}\n\n`;
    
    results.forEach((result, index) => {
        text += `${index + 1}. URL: ${result.url}\n`;
        text += `${'─'.repeat(60)}\n`;
        
        if (result.error) {
            text += `Status: ERROR\n`;
            text += `Error: ${result.error}\n`;
        } else {
            text += `Status: SUCCESS\n`;
            text += `Total Dates: ${result.total_dates}\n`;
            
            if (result.visible_dates.length > 0) {
                text += `\nVisible Content Dates (${result.visible_dates.length}):\n`;
                result.visible_dates.forEach(date => {
                    text += `  • ${date}\n`;
                });
            }
            
            if (result.source_dates.length > 0) {
                text += `\nSource Code Dates (${result.source_dates.length}):\n`;
                result.source_dates.forEach(date => {
                    text += `  • ${date}\n`;
                });
            }
            
            if (result.total_dates === 0) {
                text += `\nNo dates found on this page.\n`;
            }
        }
        text += '\n';
    });
    
    const blob = new Blob([text], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bulk-date-extraction-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    showAlert('Bulk results downloaded successfully!', 'success');
}

// Download results as CSV file
function downloadAsCSV() {
    const results = getBulkResultsData();
    if (!results) return;
    
    let csv = 'URL,Status,Total Dates,Visible Dates,Source Dates,Error\n';
    
    results.forEach(result => {
        const url = `"${result.url.replace(/"/g, '""')}"`;
        const status = result.error ? 'ERROR' : 'SUCCESS';
        const totalDates = result.total_dates;
        const visibleDates = `"${result.visible_dates.join('; ').replace(/"/g, '""')}"`;
        const sourceDates = `"${result.source_dates.join('; ').replace(/"/g, '""')}"`;
        const error = result.error ? `"${result.error.replace(/"/g, '""')}"` : '';
        
        csv += `${url},${status},${totalDates},${visibleDates},${sourceDates},${error}\n`;
    });
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bulk-date-extraction-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    showAlert('CSV file downloaded successfully!', 'success');
}

// Get bulk results data from the page
function getBulkResultsData() {
    const dataElement = document.getElementById('bulk-results-data');
    if (!dataElement) return null;
    
    try {
        return JSON.parse(dataElement.textContent);
    } catch (e) {
        console.error('Failed to parse bulk results data:', e);
        return null;
    }
}