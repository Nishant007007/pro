// Date Extractor JavaScript functionality

document.addEventListener('DOMContentLoaded', function() {
    // Form submission handling
    const extractForm = document.getElementById('extractForm');
    const extractBtn = document.getElementById('extractBtn');
    
    if (extractForm && extractBtn) {
        extractForm.addEventListener('submit', function(e) {
            // Show loading state
            extractBtn.classList.add('loading');
            extractBtn.disabled = true;
            
            // Get active tab to determine processing mode
            const activeTab = document.querySelector('.nav-link.active');
            const isBulkMode = activeTab && activeTab.id === 'bulk-tab';
            
            if (isBulkMode) {
                // Bulk mode validation
                const urlsBulkInput = document.getElementById('urls_bulk');
                const urlsText = urlsBulkInput.value.trim();
                
                if (!urlsText) {
                    e.preventDefault();
                    extractBtn.classList.remove('loading');
                    extractBtn.disabled = false;
                    showAlert('Please enter at least one URL in the bulk input.', 'error');
                    return;
                }
                
                // Count URLs and validate limit
                const urls = urlsText.split('\n').filter(line => line.trim());
                if (urls.length > 20) {
                    e.preventDefault();
                    extractBtn.classList.remove('loading');
                    extractBtn.disabled = false;
                    showAlert('Maximum 20 URLs allowed for bulk processing.', 'error');
                    return;
                }
                
                // Update button text for bulk processing
                const btnText = extractBtn.querySelector('.btn-text');
                if (btnText) {
                    btnText.textContent = `Processing ${urls.length} URLs...`;
                }
            } else {
                // Single URL mode validation
                const urlInput = document.getElementById('url');
                const url = urlInput.value.trim();
                
                if (!url) {
                    e.preventDefault();
                    extractBtn.classList.remove('loading');
                    extractBtn.disabled = false;
                    showAlert('Please enter a URL.', 'error');
                    return;
                }
                
                // Auto-add https:// if no protocol specified
                if (!url.startsWith('http://') && !url.startsWith('https://')) {
                    urlInput.value = 'https://' + url;
                }
            }
        });
    }
    
    // Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        if (!alert.querySelector('.btn-close')) return;
        
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
});

// Copy to clipboard functionality
function copyToClipboard() {
    const datesData = getDatesData();
    if (!datesData) return;
    
    let text = `Date Extraction Results from: ${datesData.url}\n`;
    text += `Generated on: ${new Date().toISOString()}\n\n`;
    
    if (datesData.visible_dates.length > 0) {
        text += `Visible Content Dates (${datesData.visible_dates.length}):\n`;
        datesData.visible_dates.forEach(date => {
            text += `- ${date}\n`;
        });
        text += '\n';
    }
    
    if (datesData.source_dates.length > 0) {
        text += `Source Code Dates (${datesData.source_dates.length}):\n`;
        datesData.source_dates.forEach(date => {
            text += `- ${date}\n`;
        });
        text += '\n';
    }
    
    text += `Total Dates Found: ${datesData.all_dates.length}`;
    
    navigator.clipboard.writeText(text).then(() => {
        showAlert('Results copied to clipboard!', 'success');
    }).catch(err => {
        console.error('Failed to copy: ', err);
        showAlert('Failed to copy to clipboard.', 'error');
    });
}

// Download as text file
function downloadAsText() {
    const datesData = getDatesData();
    if (!datesData) return;
    
    let text = `Date Extraction Results\n`;
    text += `========================\n\n`;
    text += `URL: ${datesData.url}\n`;
    text += `Generated: ${new Date().toISOString()}\n\n`;
    
    if (datesData.visible_dates.length > 0) {
        text += `Visible Content Dates (${datesData.visible_dates.length}):\n`;
        text += `${'='.repeat(40)}\n`;
        datesData.visible_dates.forEach(date => {
            text += `${date}\n`;
        });
        text += '\n';
    }
    
    if (datesData.source_dates.length > 0) {
        text += `Source Code Dates (${datesData.source_dates.length}):\n`;
        text += `${'='.repeat(35)}\n`;
        datesData.source_dates.forEach(date => {
            text += `${date}\n`;
        });
        text += '\n';
    }
    
    text += `\nSummary:\n`;
    text += `--------\n`;
    text += `Total Dates Found: ${datesData.all_dates.length}\n`;
    text += `Visible Content: ${datesData.visible_dates.length}\n`;
    text += `Source Code: ${datesData.source_dates.length}\n`;
    
    const blob = new Blob([text], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `date-extraction-results-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    showAlert('Results downloaded successfully!', 'success');
}

// Get dates data from the page
function getDatesData() {
    const dataElement = document.getElementById('dates-data');
    if (!dataElement) return null;
    
    try {
        return JSON.parse(dataElement.textContent);
    } catch (e) {
        console.error('Failed to parse dates data:', e);
        return null;
    }
}

// Show alert message
function showAlert(message, type = 'info') {
    const alertContainer = document.querySelector('.container .row:first-child .col-lg-8, .container .row:first-child .col-lg-10');
    if (!alertContainer) return;
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        <i class="fas fa-${type === 'error' ? 'exclamation-triangle' : type === 'success' ? 'check-circle' : 'info-circle'} me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    alertContainer.insertBefore(alertDiv, alertContainer.firstChild);
    
    // Auto-dismiss after 3 seconds
    setTimeout(() => {
        const bsAlert = new bootstrap.Alert(alertDiv);
        bsAlert.close();
    }, 3000);
}

// URL validation
function isValidUrl(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}

// Enhance URL input with validation
document.addEventListener('DOMContentLoaded', function() {
    const urlInput = document.getElementById('url');
    if (!urlInput) return;
    
    urlInput.addEventListener('blur', function() {
        const url = this.value.trim();
        if (url && !url.startsWith('http://') && !url.startsWith('https://')) {
            this.value = 'https://' + url;
        }
    });
    
    // Real-time validation feedback
    urlInput.addEventListener('input', function() {
        const url = this.value.trim();
        if (url && !isValidUrl(url) && !isValidUrl('https://' + url)) {
            this.classList.add('is-invalid');
        } else {
            this.classList.remove('is-invalid');
        }
    });
});
