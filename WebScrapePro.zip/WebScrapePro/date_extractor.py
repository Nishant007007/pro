import requests
from bs4 import BeautifulSoup
import re
import logging

# Configure logging
logger = logging.getLogger(__name__)

def extract_dates_visible_content(soup):
    """Extract dates from visible content (time tags, meta tags)."""
    dates = []

    # Look for <time> tags (often used for dates)
    time_tags = soup.find_all('time')
    for tag in time_tags:
        if 'datetime' in tag.attrs:
            dates.append(tag['datetime'])
        else:
            text = tag.text.strip()
            if text:
                dates.append(text)
    
    # Look for meta tags that might contain dates
    meta_tags = soup.find_all('meta')
    for meta in meta_tags:
        if 'property' in meta.attrs and 'article:published_time' in meta['property']:
            if 'content' in meta.attrs:
                dates.append(meta['content'])
        if 'name' in meta.attrs and 'date' in meta['name']:
            if 'content' in meta.attrs:
                dates.append(meta['content'])
        # Check for other common date meta tags
        if 'name' in meta.attrs and meta['name'].lower() in ['pubdate', 'publication-date', 'created', 'modified']:
            if 'content' in meta.attrs:
                dates.append(meta['content'])

    # Look for common date patterns in visible text
    text_content = soup.get_text()
    
    # Pattern for dates like 2024-01-15, 2024/01/15, 01/15/2024, etc.
    date_patterns = [
        r'\b\d{4}-\d{1,2}-\d{1,2}\b',  # YYYY-MM-DD
        r'\b\d{4}/\d{1,2}/\d{1,2}\b',  # YYYY/MM/DD
        r'\b\d{1,2}/\d{1,2}/\d{4}\b',  # MM/DD/YYYY
        r'\b\d{1,2}-\d{1,2}-\d{4}\b',  # MM-DD-YYYY
        r'\b\d{1,2}\.\d{1,2}\.\d{4}\b', # MM.DD.YYYY
    ]
    
    for pattern in date_patterns:
        matches = re.findall(pattern, text_content)
        dates.extend(matches)

    return list(set(dates))  # Remove duplicates

def extract_dates_from_source_page(url):
    """Extract all dates from the source page, based on the semicolon clue."""
    try:
        # Fetch the webpage source code
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        
        # Use regex to find all dates in the format YYYY-MM-DD after a semicolon
        # This will look for patterns like `;2024-07-01`
        date_pattern = re.compile(r';(\d{4}-\d{2}-\d{2})')
        matches = date_pattern.findall(response.text)
        
        # Also look for other date patterns in source code
        additional_patterns = [
            r'date["\']?\s*[:=]\s*["\']?(\d{4}-\d{1,2}-\d{1,2})["\']?',  # date: "2024-01-15"
            r'timestamp["\']?\s*[:=]\s*["\']?(\d{4}-\d{1,2}-\d{1,2})["\']?',  # timestamp: "2024-01-15"
            r'created["\']?\s*[:=]\s*["\']?(\d{4}-\d{1,2}-\d{1,2})["\']?',  # created: "2024-01-15"
        ]
        
        for pattern in additional_patterns:
            additional_matches = re.findall(pattern, response.text, re.IGNORECASE)
            matches.extend(additional_matches)
        
        return list(set(matches))  # Remove duplicates
    
    except Exception as e:
        logger.error(f"Error extracting dates from source: {str(e)}")
        return []

def extract_all_dates_from_page(url):
    """Extract all dates from the webpage using multiple methods."""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.content, 'html.parser')

        # Extract dates from visible content
        visible_dates = extract_dates_visible_content(soup)
        logger.info(f"Found {len(visible_dates)} visible dates")

        # Extract dates from the source page (after semicolon and other patterns)
        source_dates = extract_dates_from_source_page(url)
        logger.info(f"Found {len(source_dates)} source dates")

        # Return structured data
        return {
            'visible_dates': visible_dates,
            'source_dates': source_dates
        }
    
    except requests.exceptions.RequestException as e:
        logger.error(f"Request error: {str(e)}")
        raise
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        raise
