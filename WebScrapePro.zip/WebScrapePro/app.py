import os
import logging
from flask import Flask, render_template, request, flash, redirect, url_for
from werkzeug.middleware.proxy_fix import ProxyFix
from date_extractor import extract_all_dates_from_page
from urllib.parse import urlparse

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

def is_valid_url(url):
    """Validate if the provided URL has a proper scheme and netloc."""
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except:
        return False

@app.route('/')
def index():
    """Main page with URL input form."""
    return render_template('index.html')

@app.route('/extract', methods=['POST'])
def extract_dates():
    """Extract dates from the provided URL(s)."""
    url = request.form.get('url', '').strip()
    urls_text = request.form.get('urls_bulk', '').strip()
    
    # Determine if this is single URL or bulk processing
    if urls_text:
        # Bulk processing
        urls = [line.strip() for line in urls_text.split('\n') if line.strip()]
        if not urls:
            flash('Please enter at least one URL in the bulk input.', 'error')
            return redirect(url_for('index'))
        return process_bulk_urls(urls)
    else:
        # Single URL processing
        if not url:
            flash('Please enter a URL.', 'error')
            return redirect(url_for('index'))
        return process_single_url(url)

def process_single_url(url):
    """Process a single URL for date extraction."""
    # Add http:// if no scheme is provided
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
    
    # Validate URL format
    if not is_valid_url(url):
        flash('Please enter a valid URL.', 'error')
        return redirect(url_for('index'))
    
    try:
        # Extract dates using the date extractor
        app.logger.info(f"Extracting dates from: {url}")
        result = extract_all_dates_from_page(url)
        
        if isinstance(result, str) and result == "No dates found":
            flash('No dates were found on this webpage.', 'warning')
            return render_template('results.html', url=url, dates=[], visible_dates=[], source_dates=[], is_bulk=False)
        
        # Separate visible dates from source dates for better display
        visible_dates = result.get('visible_dates', [])
        source_dates = result.get('source_dates', [])
        all_dates = visible_dates + source_dates
        
        app.logger.info(f"Found {len(all_dates)} dates total")
        
        return render_template('results.html', 
                             url=url, 
                             dates=all_dates,
                             visible_dates=visible_dates,
                             source_dates=source_dates,
                             is_bulk=False)
        
    except Exception as e:
        app.logger.error(f"Error extracting dates from {url}: {str(e)}")
        flash(f'Error processing {url}: {str(e)}', 'error')
        return redirect(url_for('index'))

def process_bulk_urls(urls):
    """Process multiple URLs for date extraction."""
    results = []
    total_dates = 0
    
    for url in urls:
        # Add http:// if no scheme is provided
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        # Validate URL format
        if not is_valid_url(url):
            results.append({
                'url': url,
                'error': 'Invalid URL format',
                'visible_dates': [],
                'source_dates': [],
                'total_dates': 0
            })
            continue
        
        try:
            app.logger.info(f"Extracting dates from: {url}")
            result = extract_all_dates_from_page(url)
            
            if isinstance(result, str) and result == "No dates found":
                visible_dates = []
                source_dates = []
            else:
                visible_dates = result.get('visible_dates', [])
                source_dates = result.get('source_dates', [])
            
            all_dates = visible_dates + source_dates
            total_dates += len(all_dates)
            
            results.append({
                'url': url,
                'visible_dates': visible_dates,
                'source_dates': source_dates,
                'total_dates': len(all_dates),
                'error': None
            })
            
            app.logger.info(f"Found {len(all_dates)} dates from {url}")
            
        except Exception as e:
            app.logger.error(f"Error extracting dates from {url}: {str(e)}")
            results.append({
                'url': url,
                'error': str(e),
                'visible_dates': [],
                'source_dates': [],
                'total_dates': 0
            })
    
    app.logger.info(f"Bulk processing complete: {len(results)} URLs, {total_dates} total dates")
    
    return render_template('bulk_results.html', 
                         results=results,
                         total_urls=len(results),
                         total_dates=total_dates,
                         is_bulk=True)

@app.errorhandler(404)
def page_not_found(e):
    """Handle 404 errors."""
    return render_template('index.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    """Handle 500 errors."""
    app.logger.error(f"Internal server error: {str(e)}")
    flash('An internal server error occurred.', 'error')
    return render_template('index.html'), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
